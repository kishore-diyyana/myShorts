package com.test.ip;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/IPTest")
public class IPTest extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Writer writer = response.getWriter();

		writer.append("Served at: ").append(request.getContextPath());
		writer.append("<html> <body> ");
		writer.append("<h1> IP Test ...</h1>");
		writer.append("</body> </html>");

		List <String> urls = new ArrayList<String> ();

		//populateQTI_Part1(urls);

		populateQTI_Part2(urls);

		testURLs(urls);
		/*testURL3_Invalid();
		//ipTest1();
		testURL1_Invalid();*/
	}

	private void populateQTI_Part2(List <String> urls) {

		urls.add("http://myURI/path");
	}

	private void populateQTI_Part1(List <String> urls) {

		urls.add("http://IP:PORT");

	}


	public void testURLs(List <String> urls) {
	    int size = 0;
	    	for (String urlStr: urls) {
	    		try {
	    			size++;
			        URL url = new URL(urlStr);
			        System.out.println("Testing.......... URL "+size+"  --> "+url);
			        HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
			        urlConn.connect();
			        if (HttpURLConnection.HTTP_OK == urlConn.getResponseCode()) {
			        	System.out.println("Success............."+urlConn.getResponseCode());
			        }
			        else {
			        	System.out.println("Failure............."+urlConn.getResponseCode());
			        }
		    	}
	    		catch (IOException e) {
	    		        System.err.println("IOException : Error creating HTTP connection");
	    		        e.printStackTrace();
	    		    }
	    		catch(Exception e) {
	  	    	  System.err.println("Exception: Error creating HTTP connection");
	  		        e.printStackTrace();
	    		}
	    	}
	}

	public void testURL3_Invalid() {
	    String strUrl = "http://IP:PORT";
	    try {
	        URL url = new URL(strUrl);
	        System.out.println("Testing..........URL...:"+url);
	        HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
	        urlConn.connect();

	        if (HttpURLConnection.HTTP_OK == urlConn.getResponseCode()) {
	        	System.out.println("Success............."+urlConn.getResponseCode());
	        }
	        else {
	        	System.out.println("Failure............."+urlConn.getResponseCode());
	        }
	    } catch (IOException e) {
	        System.err.println("IOException : Error creating HTTP connection");
	        e.printStackTrace();

	    }
	    catch(Exception e) {
	    	  System.err.println("Exception: Error creating HTTP connection");
		        e.printStackTrace();
	    }
	}

	public void testURL1_Invalid() {
		System.out.println("testURL1_Invalid..............");
	    String strUrl = "http://IP:PORT";
	    try {
	        URL url = new URL(strUrl);
	        System.out.println("testURL1_Invalid:Testing..........URL...:::"+url);
	        HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
	        urlConn.connect();

	        if (HttpURLConnection.HTTP_OK == urlConn.getResponseCode()) {
	        	System.out.println("Success............."+urlConn.getResponseCode());
	        }
	        else {
	        	System.out.println("Failure............."+urlConn.getResponseCode());
	        }
	    } catch (IOException e) {
	        System.err.println("IOException : Error creating HTTP connection");
	        e.printStackTrace();

	    }
	    catch(Exception e) {
	    	  System.err.println("Exception: Error creating HTTP connection");
		        e.printStackTrace();
	    }
	}

	private void ping(String cmd) {
		try {
			Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(p.getInputStream()));

			String s = "";
			// reading output stream of the command
			while ((s = inputStream.readLine()) != null) {
				System.out.println(s);
			}

		} catch (Exception e) {
			System.out.println("ipTest Exception "+e);
			e.printStackTrace();
		}
	}

	private void ipTest1( ) {

		String ip = "ping <IP>";
		System.out.println("IP Testing::::::::::::::::::::::::::::: "+ip);
		ping(ip);
	}


	  /* public static void main(String[] args) throws Exception {
	        //connect to database

		   DBTest test = new DBTest();
		   test.test1();
		   test.test2();
		   test.test3();

		   Class.forName("oracle.jdbc.driver.OracleDriver");
	        ArrayList<String> serverNames = new ArrayList<String>();
	        serverNames.add("<IP>");
	        serverNames.add("yourhostname2");
	        serverNames.add("yourhostname3");
	        serverNames.add("yourhostname4");
	        String portNumber = "1521";
	        String sid = "ORCLSID";
	        String url = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(LOAD_BALANCE=ON)(FAILOVER=ON)" ;
	        for (String serverName : serverNames) {
	        	System.out.println("Testing : "+serverName);
	        	url += "(ADDRESS=(PROTOCOL=tcp)(HOST="+serverName+")(PORT="+portNumber+"))";
	        }
	        url += ")(CONNECT_DATA=(SID="+sid+")))";
	        String username = "USERNAME";
	        String password = "PASSWORD";
	        // System.out.println(url); // for debugging, if you want to see the url that was built
	        Connection conn = DriverManager.getConnection(url, username, password);
	    }*/



	   private void test1() {

		   System.out.println("Testing Oracle 1..........");
		   String DB_URL = "jdbc:oracle:thin:@//<IP>:1521/<SERVICENAME>";
		   String USER = "user";
		   String PASS = "pwd";
		   connectOracleDB(DB_URL, USER, PASS);
	   }

	   private void test2() {

		   System.out.println("Testing Oracle 2..........");
		   String DB_URL = "jdbc:oracle:thin:@//<IP>:1521/<SERVICENAME>";
		   String USER = "user";
		   String PASS = "pwd";
		   connectOracleDB(DB_URL, USER, PASS);
	   }

	   private void test3() {

		   System.out.println("Testing DB2 3..........");
		   String DB_URL = "jdbc:db2://<IP>:1521/<SERVICENAME>";
		  String USER = "user";
		   String PASS = "pwd";
		   connectDB2(DB_URL, USER, PASS);
	   }

	   private void connectOracleDB(String DB_URL, String USER, String PASS) {
		   Connection conn = null;

		    try {
		      Class.forName("oracle.jdbc.driver.OracleDriver");
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL, USER, PASS);
		    } catch (Exception e) {
		    	System.out.println("Exception ");
		      e.printStackTrace();
		    } finally {
		      if (conn != null) {
		        try {
		          conn.close();
		        } catch (SQLException e) {
		        	System.out.println("SQLException ");
		          e.printStackTrace();
		        }
		      }
		    }
	   }

	   private void connectDB2(String DB_URL, String USER, String PASS) {
		   	String jdbcClassName="com.ibm.db2.jcc.DB2Driver";
	        Connection connection = null;
	        try {
	            //Load class into memory
	            Class.forName(jdbcClassName);
	            //Establish connection
	            connection = DriverManager.getConnection(DB_URL, USER, PASS);

	        } catch (ClassNotFoundException e) {
	        	System.out.println("ClassNotFoundException ");
	            e.printStackTrace();
	        } catch (SQLException e) {
	        	System.out.println("1 SQLException ");
	            e.printStackTrace();
	        }finally{
	            if(connection!=null){
	                System.out.println("Connected successfully.");
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                	System.out.println("2 SQLException ");
	                    e.printStackTrace();
	                }
	            }
	        }
	   }
}
